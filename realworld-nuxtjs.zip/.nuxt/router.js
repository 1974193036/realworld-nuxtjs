import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _40f2667d = () => interopDefault(import('../pages/layout/index.vue' /* webpackChunkName: "" */))
const _f6e7601c = () => interopDefault(import('../pages/home/index.vue' /* webpackChunkName: "" */))
const _1fd97f8c = () => interopDefault(import('../pages/login/index.vue' /* webpackChunkName: "" */))
const _235157cc = () => interopDefault(import('../pages/profile/index.vue' /* webpackChunkName: "" */))
const _733a9394 = () => interopDefault(import('../pages/settings/index.vue' /* webpackChunkName: "" */))
const _5646d500 = () => interopDefault(import('../pages/editor/index.vue' /* webpackChunkName: "" */))
const _392d9ed9 = () => interopDefault(import('../pages/article/index.vue' /* webpackChunkName: "" */))
const _613d0018 = () => interopDefault(import('../pages/404.vue' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _40f2667d,
    children: [{
      path: "",
      component: _f6e7601c,
      name: "home"
    }, {
      path: "/login",
      component: _1fd97f8c,
      name: "login"
    }, {
      path: "/register",
      component: _1fd97f8c,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _235157cc,
      name: "profile"
    }, {
      path: "/settings",
      component: _733a9394,
      name: "settings"
    }, {
      path: "/editor",
      component: _5646d500,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _392d9ed9,
      name: "article"
    }]
  }, {
    path: "*",
    component: _613d0018,
    name: "custom"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
